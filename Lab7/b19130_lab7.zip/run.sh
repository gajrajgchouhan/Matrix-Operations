
set -e

g++ -Ofast -g Matrix.hpp Algos.hpp main.cpp -o a.out

echo "Run using ./a.out"
