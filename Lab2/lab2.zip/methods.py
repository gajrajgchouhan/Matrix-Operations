import numpy as np


class GaussianElimination(object):
    """docstring for GaussianElimination"""

    def __init__(self, A, B):
        self.A = np.copy(np.array(A))
        self.B = np.copy(np.array(B))
        self.n = A.shape[0]
        self.X = np.zeros_like(B)

    def solve(self):
        for col in range(self.n):

            # pivoting
            mx = self.A[col][col]
            mx_row = col
            for row in range(col + 1, self.n):
                if self.A[row][col] > mx:
                    mx = self.A[row][col]
                    mx_row = row

            tmp1 = self.B[col]
            tmp2 = self.B[mx_row]
            self.B[mx_row] = tmp1
            self.B[col] = tmp2

            for col2 in range(self.n):
                tmp1 = self.A[col][col2]
                tmp2 = self.A[mx_row][col2]

                self.A[col][col2] = tmp2
                self.A[mx_row][col2] = tmp1
            # end pivoting

            for row in range(col + 1, self.n):
                m = self.A[row][col] / self.A[col][col]
                for i in range(col, self.n):
                    self.A[row][i] -= self.A[col][i] * m
                self.B[row] -= self.B[col] * m

        for i in range(self.n - 1, -1, -1):
            if i == self.n - 1:
                self.X[i] = self.B[i] / self.A[i][i]
            else:
                s = 0
                for j in range(i + 1, self.n):
                    s += self.A[i][j] * self.X[j]
                self.X[i] = (self.B[i] - s) / self.A[i][i]


class LU(object):
    """
    L is lower triangular matrix
    U is upper triangulat matrix"""

    def __init__(self, A, B):
        self.A = np.array(A)
        self.B = np.array(B)
        self.n = self.A.shape[0]
        self.L = np.zeros_like(A)
        self.U = np.zeros_like(A)
        self.X = np.zeros_like(B)

    def solve(self):
        # A = LU
        # LUX = B
        # UX = y => Ly = B
        self._calcLU()
        G = GaussianElimination(self.L, self.B)
        G.solve()
        Y = np.copy(G.X)
        G = GaussianElimination(self.U, Y)
        G.solve()
        self.X = np.copy(G.X)

    def _calcLU(self):
        for i in range(self.n):
            for j in range(i):
                total = 0
                for k in range(j):
                    total += self.L[i][k] * self.U[k][j]
                self.L[i][j] = (self.A[i][j] - total) / self.U[j][j]
            self.L[i][i] = 1
            for j in range(i, self.n):
                total = 0
                for k in range(i):
                    total += self.L[i][k] * self.U[k][j]
                self.U[i][j] = self.A[i][j] - total


class QR(object):
    """Q is orthogonal
    R is upper triangular matrix
    can be used to find eigenvalues"""

    def __init__(self, A, B):
        self.A = np.copy(A)
        self.B = np.copy(B)
        self.n = A.shape[0]
        self.Q = np.zeros_like(A)
        self.R = np.zeros_like(A)
        self.y = np.zeros_like(B)

    def solve(self):
        for j in range(self.n):
            q = np.zeros(self.n)
            for i in range(self.n):
                q[i] = A[i, j]
                if i < j:
                    ri = 0
                    for k in range(self.n):
                        ri += self.Q[k, i] * A[k, j]
                    self.R[i, j] = ri

            for i in range(self.n):
                for k in range(j):
                    q[i] -= self.R[k, j] * self.Q[i, k]

            for x in q:
                self.R[j, j] += x ** 2
            self.R[j, j] = self.R[j, j] ** 0.5

            for i in range(self.n):
                self.Q[i, j] = q[i] / self.R[j, j]

        for j in range(self.n):
            for i in range(self.n):
                y[j] += self.Q[i, j] * b[i]

        x = y
        for i in range(self.n - 1, -1, -1):
            for j in range(i + 1, self.n):
                if j != i:
                    x[i] -= self.R[i][j] * x[j]
            x[i] /= self.R[i][i]

        return x


class Cholesky(object):
    """
    only if A is symmetric
    A should be POSITIVE DEFINITE
    A is L.Lt
    """

    def __init__(self):
        pass
